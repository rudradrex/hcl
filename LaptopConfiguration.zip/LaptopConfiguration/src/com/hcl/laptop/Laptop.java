package com.hcl.laptop;

public class Laptop {

	private String os;
	private String camera;
	private String speaker;
	private String processor;
	private String battery;
	private String screen;
	private String ram;
	private String hardDiskSpace;

	public String getOs() {
		return os;
	}

	public Laptop(String os, String camera, String speaker, String processor, String battery, String screen, String ram,
			String hardDiskSpace) {
		super();
		this.os = os;
		this.camera = camera;
		this.speaker = speaker;
		this.processor = processor;
		this.battery = battery;
		this.screen = screen;
		this.ram = ram;
		this.hardDiskSpace = hardDiskSpace;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public String getCamera() {
		return camera;
	}

	public void setCamera(String camera) {
		this.camera = camera;
	}

	public String getSpeaker() {
		return speaker;
	}

	public void setSpeaker(String speaker) {
		this.speaker = speaker;
	}

	public String getProcessor() {
		return processor;
	}

	public void setProcessor(String processor) {
		this.processor = processor;
	}

	public String getBattery() {
		return battery;
	}

	public void setBattery(String battery) {
		this.battery = battery;
	}

	public String getScreen() {
		return screen;
	}

	public void setScreen(String screen) {
		this.screen = screen;
	}

	public String getRam() {
		return ram;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public String getHardDiskSpace() {
		return hardDiskSpace;
	}

	public void setHardDiskSpace(String hardDiskSpace) {
		this.hardDiskSpace = hardDiskSpace;
	}

	@Override
	public String toString() {
		return "Laptop [os=" + os + ", camera=" + camera + ", speaker=" + speaker + ", processor=" + processor
				+ ", battery=" + battery + ", screen=" + screen + ", ram=" + ram + ", hardDiskSpace=" + hardDiskSpace
				+ "]";
	}

}
