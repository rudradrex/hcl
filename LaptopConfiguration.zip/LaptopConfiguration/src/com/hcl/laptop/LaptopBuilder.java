package com.hcl.laptop;

public class LaptopBuilder {

	private String os;
	private String camera;
	private String speaker;
	private String processor;
	private String battery;
	private String screen;
	private String ram;
	private String hardDiskSpace;

	public LaptopBuilder(String os) {
		this.os = os;
	}

	public LaptopBuilder setCamera(String camera) {
		this.camera = camera;
		return this;
	}

	public LaptopBuilder setSpeaker(String speaker) {
		this.speaker = speaker;
		return this;
	}

	public LaptopBuilder setProcessor(String processor) {
		this.processor = processor;
		return this;
	}

	public LaptopBuilder setBattery(String battery) {
		this.battery = battery;
		return this;
	}

	public LaptopBuilder setScreen(String screen) {
		this.screen = screen;
		return this;
	}

	public LaptopBuilder setRam(String ram) {
		this.ram = ram;
		return this;
	}

	public LaptopBuilder setHardDiskSpace(String hardDiskSpace) {
		this.hardDiskSpace = hardDiskSpace;
		return this;
	}

	public Laptop build() {
		return new Laptop(os, camera, speaker, processor, battery, screen, ram, hardDiskSpace);
	}

}
