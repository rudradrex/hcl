package com.hcl.laptop;

public class LaptopConfigurationMain {

	public static void main(String[] args) {

		Laptop laptop1 = new LaptopBuilder("MAC").build();
		System.out.println(laptop1);

		Laptop laptop2 = new LaptopBuilder("MAC").setRam("16 GB").build();
		System.out.println(laptop2);

		Laptop laptop3 = new LaptopBuilder("MAC").setCamera("8 pixels").setBattery("3500nmAH").setRam("16 GB")
				.setHardDiskSpace("1TB").build();
		System.out.println(laptop3);

	}

}
